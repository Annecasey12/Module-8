package com.example.inventoryapp

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast

class ProductActivity : AppCompatActivity() {
    private var tl: TableLayout? = null
    private var product_name: EditText? = null
    private var product_description: EditText? = null
    private var addItem: Button? = null
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)
        product_name = findViewById(R.id.product_name_input) as EditText?
        product_description = findViewById(R.id.product_description_input) as EditText?
        tl = findViewById(R.id.tableLayout) as TableLayout?
        addItem = findViewById(R.id.addItem) as Button?
        addItem.setOnClickListener(object : OnClickListener() {
            fun onClick(v: View?) {
                val intent = Intent(this@ProductActivity, databaseActivity::class.java)
                startActivity(intent)
            }
        })
        populateTable()
    }

    fun newProduct(view: View?) {
        val e_productname: String = product_name.getText().toString()
        val e_productdesc: String = product_description.getText().toString()
        if (e_productname.isEmpty() || e_productdesc.isEmpty()) {
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show()
            return
        }
        /**Add to databatabase */
        val dbHandler = MyDBHandler(this, null, null, 1)
        val product = Product(e_productname, e_productdesc)
        dbHandler.addProduct(product)
        /** */
        product_name.setText("")
        product_description.setText("")
        populateTable()
    }

    fun lookUpProduct(view: View) {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val row: TableRow = view.getParent() as TableRow
        val textView: TextView = row.getChildAt(1) as TextView
        val product: Product = dbHandler.findProduct(textView.getText().toString())
        if (product != null) {
            product_name.setText(product.getProductName())
            product_description.setText(product.getDescription())
        } else {
            product_name.setText("No Match Found")
        }
    }

    fun removeProduct(view: View): Boolean {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val row: TableRow = view.getParent() as TableRow
        val textView: TextView = row.getChildAt(1) as TextView
        val result: Boolean = dbHandler.deleteProduct(textView.getText().toString())
        if (result) {
            product_name.setText("Record Deleted")
            product_description.setText("")
        } else product_name.setText("No Match Found")
        return result
    }

    fun deleteRow(v: View) {
        val row: View = v.getParent() as View
        val container: ViewGroup = row.getParent() as ViewGroup
        container.removeView(row)
        container.invalidate()
    }

    fun populateTable() {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val productList: java.util.ArrayList<Product> = dbHandler.selectAllProducts()
        val count: Int = tl.getChildCount()
        tl.removeViews(1, count - 1)
        for (product in productList) {
            val tr = TableRow(this)
            tr.setLayoutParams(
                LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            tr.setBackgroundColor(Color.parseColor("#DAE8FC"))
            tr.setPadding(5, 5, 5, 5)
            val tx1 = TextView(this)
            val tx2 = TextView(this)
            val tx3 = TextView(this)
            tx1.setText(java.lang.String.valueOf(product.getID()))
            tx2.setText(product.getProductName())
            tx3.setText(countItems(product.getProductName()))
            val img = ImageView(this)
            img.setImageResource(R.drawable.ic_action_delete)
            img.setOnClickListener(object : OnClickListener() {
                fun onClick(v: View) {
                    if (removeProduct(v)) deleteRow(v)
                }
            })
            val img1 = ImageView(this)
            img1.setImageResource(R.drawable.ic_action_edit)
            img1.setOnClickListener(object : OnClickListener() {
                fun onClick(v: View) {
                    lookUpProduct(v)
                }
            })
            tr.addView(tx1)
            tr.addView(tx2)
            tr.addView(tx3)
            tr.addView(img)
            tr.addView(img1)
            tl.addView(tr)
        }
    }

    fun countItems(productName: String): String {
        var count = 0
        val items: java.util.ArrayList<Item> = java.util.ArrayList<Item>()
        for (item in items) {
            count++
        }
        sendSMS(productName)
        return count.toString()
    }

    fun sendSMS(item_name: String) {
        val phoneNo = "+2154658978" //txtphoneNo.getText().toString();
        val message = "$item_name Time to Restock"
        try {
            val smgr: SmsManager = SmsManager.getDefault()
            smgr.sendTextMessage(phoneNo, null, message, null, null)
            Toast.makeText(this@ProductActivity, "SMS Sent Successfully", Toast.LENGTH_SHORT).show()
        } catch (e: java.lang.Exception) {
            Toast.makeText(
                this@ProductActivity,
                "SMS Failed to Send, Please try again",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}